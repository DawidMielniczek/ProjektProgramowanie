Create database Wypożyczalnia_samochodów

GO

use Wypożyczalnia_samochodów

GO

create table Klienci(
id_klienta int not null IDENTITY CONSTRAINT pk_Klienci PRIMARY KEY,
imie varchar(20) not null,
nazwisko varchar(20) not null,
pesel  varchar (11) not null,
miejscowosć varchar(20) not null,
nr_domu varchar (10) not null,
kontakt char(9) not null
)

GO

create table Pracownicy(
nr_pracownika int not null IDENTITY CONSTRAINT pk_Pracownicy PRIMARY KEY,
imie varchar(20) not null,
nazwisko varchar(20) not null,
Pesel varchar(11) not null,
data_zatrudnienia date not null,
Kontakt char(9) not null
)

GO

Insert into Pracownicy values ('XYZ','Kowalski','99887766543', '2021-02-05',889960748)

GO

create table Samochody(
 id_samochodu int not null IDENTITY CONSTRAINT pk_Samochody PRIMARY KEY,
 Marka varchar(20) not null,
 Model varchar(20) not null,
 Poj_silnika Float(10) not null,
 Rok_prod int  not null,
 Dostępność varchar(3) not null
)

GO

insert into Samochody values ('Volkswagen', 'Passat','1898', 2010, 'tak')
insert into Samochody values ('Volkswagen', 'golf','1597', 2010, 'tak')
insert into Samochody values ('Seat', 'Leon','2479', 2010, 'tak')

GO

create table Wypożyczenia(
nr_wypożyczenia int not null IDENTITY CONSTRAINT pk_Wypożyczenia PRIMARY KEY,
id_użytkownika int not null ,
id_samochodu int not null,
data_wyp date not null
)

GO

create table Wypożyczalnia(
 id_Opini int not null IDENTITY CONSTRAINT pk_Wypożyczalnia PRIMARY KEY,
 id_klienta int not null ,
 Opinia varchar(150) not null,
 Ocena int not null
)